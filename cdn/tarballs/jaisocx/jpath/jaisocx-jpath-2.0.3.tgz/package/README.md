
# JPath
  > 💡The JPath class gets or sets values of an object or array.

  | **📖️ Library**  | `@jaisocx/jpath` | **🏷️ ver.**: `2.0.3` | 

  | **🗓 Updated**  | Spring 2026, `3 mai 2026 20:24:20 UTC` | 

  | **📐 Size**     | 🗂 Folder: 105 KB | 📦 Tarball: 10 KB | 📋 .js: 14 KB | 

  | **⚡ JS Engine** | 🌐 Browser: ✅ yes | 🧭 Express: ✅ yes | 🖥️ Console: ✅ yes | 

---



## The aim of the setup
  > 💡 The JPath class gets or sets values of an object or array.

## Examples

  **JPath Expression**

  ```javascript
    let jpathExpression_js            = "data.records[0].id";
    let jpathExpression_points_joined = "data.records.0.id";
    let jpathExpression_works_too     = "data.[records]0.id";
    let jpathExpression_enbraced      = "[data][records][0][id]";
    let jpathExpression_enbraced_points_joined = "[data].[records].[0].[id]";
    let jpathExpression_jsonkey_ext_symbols_b  = "data.records[0][field 2]";
    let jpathExpression_jsonkey_ext_symbols_a  = "data.records[1].[field 2]";
  ```



  **In HTML**

  ```html
    <html>
      ...
      <div data-jpath="data.records.0.id"></div>
      ...

      <script src="node_modules/@jaisocx/jpath/transpiled/Simple/JPathData.js"></script>
      <script src="node_modules/@jaisocx/jpath/transpiled/Simple/JPath.js"></script>
      <script>
        // DOMContentLoaded ...
      </script>
    </html>
  ```



  **Typescript**

  ```typescript
    let obj: any = {
      "data": {
        "records": [
          {
            "id": 1,
            "field 2": "text line 1 of field 1"
          },
          {
            "id": 2,
            "field 2": "text line 2 of field 1"
          },
        ]
      }
    };
  
    let jPath: JPath = new JPath();
    let jpathExpression: string = "data.records[0].id";
    let id: number = jPath.getByJPathExpression( obj, jpathExpression );
  
  ```



## 🗂 Structure

```ls
🗂 JPath
    🗂 src/
      📋 index.ts
      📋 JPath.ts
      📋 JPathData.ts
      📋 JPathDataInterface.ts
      📋 JPathInterface.ts
    🗂 test/
      📋 JPath_Test.js
      📋 Split_Test.js
    🗂 transpiled/
      🗂 CommonJS/
      🗂 ESNext/
      🗂 Simple/
        📋 JPath.js
        📋 JPathData.js
    📋 jaisocx-jpath-2.0.3.tgz
    📋 package.json
    📋 package-lock.json
    📋 README.md

```



## Interfaces

  **JPathInterface**
    
  ```typescript
    // ${package}/src/JPathInterface.ts
    
    /** @class JPath:
     * 💡JPath accepts queries of datatype (string|number)[] and performs lookup in js objects and arrays
    */
    export interface JPathInterface {
    
      // jpath string exression as "subtree[1].opened" => [ "subtree", 1, "opened" ]
      // with this art of array of properties names of javascript object tree
      //  it is easier to get the property value of any datatype in javascript objects and arrays.
      //  later usage of the jpath array:
      //    let jpath = JPath.parse( "subtree[1].opened" );
      //    let obj = { "subtree": [{ "opened": false }, { "opened": true }] };
      //    let valueFound = JPath.getByJPath( jpath, obj );
      //    console.log( valueFound );
      //    prints out => true
      parse ( jpathExpression: string ): (string|number)[];
    
    
      // @method protected parseDotted( ... @args ): number
      // @inokedBy method: public parse ( jpathExpression: string ): (string|number)[]
      // splitted with symbol point, adds to jpathArray, numeric array elem id or textual field name.
      parseDotted (
          jpathExpressionDotted: string,
          jpathArray: ( string|number )[]
        ): number;
    
    
    
      serialize (
        jpath: (string|number)[],
        delimiter: string,
        start: string,
        finish: string
      ): string;
    
    
    
      getByJPathExpression (
        obj: any,
        jpathExpression: string
      ): any;
    
    
      // faster than JPath.getByJPathExpression( jpathExpression: string, value: any );
      // recommended when the lookup more than once with the same jpathExpression,
      // or when You already at once build the jpath array variables to perform lookups
      // like this: let jpath: (string|number)[] = [ "tokens", "startTokens", 0, "length" ];
      //    let jpath = JPath.parse( "subtree[1].opened" ); => [ "subtree", 1, "opened" ]
      //    let obj = { "subtree": [{ "opened": false }, { "opened": true }] };
      //    let valueFound = JPath.getByJPath( jpath, obj );
      //    console.log( valueFound );
      //    prints out => true
      getByJPath (
        obj: any,
        jpath: (string|number)[]
      ): any;
    
    
    
      setByJPathExpression (
        obj: any,
        jpathExpression: string,
        value: any
      ): JPathInterface;
    
      setByJPath (
        obj: any,
        jpath: (string|number)[],
        value: any
      ): JPathInterface;
    
      setByJPathWalkFlatRebuild (
        obj: any,
        jpath: (string|number)[],
        value: any,
        nameHolderId: string,
        nameId: string,
        branchName: string
      ): JPathInterface;
    
    }
  ```



  **JPathDataInterface**

  ```typescript
    export interface JPathDataInterface {
    
      isPlaceholderValue(): number;
    
      setIsPlaceholderValue( isPlaceholder: number ): JPathDataInterface;
    
      getJPath(): (string|number)[];
    
      setJPath( jpath: (string|number)[] ): JPathDataInterface;
    
      getJPathExpression(): string;
    
      setJPathExpression( jpathExpression: string ): JPathDataInterface;
    
    }
  ```

---



Have a nice day,

Jaisocx Software Architect Elias


